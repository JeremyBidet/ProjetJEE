
-- ------------------------------------------------------------------------------
--
-- !!!!! WARNING !!!!!
--
-- Before running next commands:
-- 
-- Import CSV files to tmp tables using ; as delimiter (other params as default) and skipping first line (headers).
-- 
-- 'liste-des-cafes-a-un-euro.csv' 					-> 		'cafe_tmp'
-- 'liste_des_sites_des_hotspots_paris_wifi.csv' 	-> 		'hotspot_wifi_tmp'
--
-- ------------------------------------------------------------------------------

